<?php
include 'db.php' ;
$db= new database();
$data =$db->getAll('tb_masyarakat');

foreach($data as $d):   
    echo $d['id_user'];
    echo "<br>";
    echo $d['nama_lengkap'];
    echo "<br>";
    echo $d['username'];
    echo "<br>";
    echo $d['password'];
    echo "<br>";
    echo "<hr>";
endforeach;

// $insert = $db->insert('tb_masyarakat', [
//     'id_user'        => '',
//     'nama_lengkap'   => 'akmal',
//     'username'       => 'mateh',
//     'password'       => '1111',
//     'telp'  => '0897382358'


// ]);

// if ($insert > 0 ) {
//     echo "Berhasil";
// } else {
//     echo "Gagal gaess...";
// }

// $delete = $db->delete('tb_masyarakat', ['id_user' => 11 ] );


// if ( $delete > 0 ){
//     echo "Berhasil";
// }else{
//     echo "Gagal gaess...";
// }
// 

// $update= $db->update('tb_masyarakat',[
//     'nama_lengkap'=> 'yulay',
//     'username'=> 'colay',
//     'password'=>'12345',
//     'telp'=> '0000000000000'
// ],
// ['id_user' => 9]);

// if ( $update > 0 ){
//     echo "Berhasil";
// }else{
//     echo "Gagal gaess...";
// }
 
// $getbyid= $db->getByid('tb_masyarakat',['id_user'=>9]);
// foreach($getbyid as $g):
//     echo $g['id_user'];
//     echo "<br>";
//     echo$g['nama_lengkap'];
//     echo "<br>";

//     echo $g['username'];
//     echo "<br>";

//     echo $g['password'];
//     echo "<br>";

//     echo$g['telp'];
//     echo "<br>";
// endforeach;
   
<?php if($_SESSION['level'] == 'Admin'){  ?>
<a href="" class="btn btnsuccess"></a>
<?php } ?>



?>